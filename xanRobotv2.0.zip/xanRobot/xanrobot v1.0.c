#include<stdio.h>
#include<stdlib.h>
//#include<winsock2.h>
//#include<mysql.h>
//#include<time.h>

	int i,n,j,m;
	int sum	= 0;
	int sumlost=10000;
	int placed[100000];
    int initial=10000; // initial stake

int main(){

//MYSQL *conn;
//conn = mysql_init(0);
//conn = mysql_real_connect(conn,"localhost","root","","xanrobot",0,NULL,0);
//if(conn){
//    printf("xanrobot launched successfully\n\n");
//}
//else {printf("you are offline!\n\n");
// exit(0);
//  }

int A[400]={1,1,0,1,1,1,1,1,0,0,1,1,0,1,1,0,0,0,1,0,
           1,1,0,1,1,1,1,1,0,0,1,1,0,1,1,1,0,1,1,0,
		   1,1,0,1,1,1,1,1,0,0,1,1,0,1,1,1,0,1,1,0,
		   1,1,0,1,1,1,1,1,0,0,1,1,0,1,1,1,0,1,1,0,
		   1,1,0,1,1,1,1,0,0,0,1,1,0,0,1,1,0,1,1,0,
		   1,1,0,1,1,1,1,1,0,0,1,1,0,1,1,1,0,1,1,0,
		   1,1,0,1,1,1,1,1,0,0,1,1,0,1,1,1,0,1,1,0,
		   1,1,0,1,1,1,1,1,0,0,1,1,0,1,1,1,0,1,1,0,
		   1,1,0,1,1,1,1,1,0,0,0,1,1,0,0,1,0,1,1,0,
		   1,1,0,1,1,1,1,1,0,0,1,1,0,1,1,1,0,1,1,0,
		   1,1,0,1,1,1,1,1,0,0,1,1,0,1,1,1,0,1,1,0,
		   1,1,0,1,1,1,1,1,0,0,1,1,0,1,1,1,0,1,1,0,
		   1,1,0,1,1,1,1,0,0,0,1,1,0,1,1,1,0,1,1,0,
		   1,1,0,1,1,1,1,1,0,1,0,1,0,1,1,1,0,1,1,0,
		   1,1,0,1,0,1,0,1,0,0,1,1,0,1,1,1,0,1,1,0,
		   1,1,0,1,1,1,1,1,0,0,1,1,0,1,1,1,0,1,1,0,
		   1,1,0,1,0,0,0,1,0,0,1,1,0,1,1,1,0,1,1,0,
		   1,1,0,1,1,1,1,1,0,0,1,1,0,1,1,1,0,1,1,0,
		   1,1,0,1,1,1,1,1,0,0,1,1,0,1,1,1,0,1,1,0,
		   1,1,0,1,1,1,1,1,0,0,1,1,0,1,1,1,0,0,1,0};  // data for 5 months
		   
int B[20]= {1,1,0,1,1,1,1,1,0,0,1,1,0,1,1,1,0,1,1,0};

int trades[56]={1,1,1,1,1,1,0,0,0,1,1,0,0,1,1,0,1,0,1,1,
                1,1,1,1,1,1,0,1,1,1,0,0,1,1,1,1,1,0,1,1,
				0,1,1,1,1,0,1,0,1,1,1,1,0,1,1,0};

int C[5]= {1,1,1,1,1};
           

	printf("=======| XANROBOT |=======\n\n");

  int total= bankroll();
  //printf("\ntotal cash needed for 4 times is %d\n",total);

	Decision(trades,56);
    //Decision(A,400);

}


int bankroll(){

       for(i=0;i<4;i++){
	printf("%d: %d\n",(i+1),sumlost);

		placed[i]=sumlost;

		//for loop for calculating the sum.
		for(j=i;j<=i;j++){
			sum+=placed[j];
		}

		sumlost=(sum+3100)/0.35;

	}
            //printf("\t\t\t%d\n",sum);
			return sum;
}



void Decision(int arr[], int n){
 int currentbal=750000;
 int counter=0;
 int count = 0; 
 int lost=initial;
 int sum1=0, loss=0;
 int placed1[100000];

	printf("");


		   for(i=0;i<n;i++){

		   	if(arr[i]==0){

				   // need to set the loss after the first win so
				   counter=0; // setting the win counter to zero.
				   count=count+1;

				   if(count==1&&lost==20000){
                       loss=lost;
					   lost=13500;
					   goto balupdate;

				   } else if(count>1||lost==10000){
                       
					   placed1[i]=lost;
					   placed1[1]=initial;
					   for(j=i;j<=i;j++){   //for loop for calculating the sum.
			            sum1+=placed1[j];
						}
				//    printf("\n%d\n",sum1); for debugging purposes.
		   			
		int profit = currentbal-750000;
		
		if(sum1>140000){
			if(profit>sum1){ 
			   loss = placed1[i];

                   printf("> you still have %d as profit\n> you also lost three times already\n",profit-sum1);
				   lost=placed1[1];   //decision when profit is greater than what we lost
			       sum1 = 0;
			   
			}  
			
			else{
			        
			 	printf("> you already exhausted all your profit\n> you also lost three times already\n");
			 	loss = placed1[i];
				//printf("%d",placed1[i]);
				lost=placed1[i]*2;      //make decision after losing with small profit
				sum1=0;
			 
			}

			}
      else{

         lost=(sum1+3100)/0.35;
    	 loss=placed1[i];
		   
		       }


				   }
				            
          balupdate:
    	  counter=0;
    	 currentbal= currentbal-loss;
    	 
			   }   

   else if(arr[i]==1){
 int win;
   	 count=0; //setting the loss counter to zero
	 counter = counter+1;     

        if(counter==1){
			 win= (1.35*lost)-lost;
   	         currentbal=currentbal+win;

			 sum1=0;
			 lost=initial*2;
		}
		else if(counter==2){
			 //lost=lost*2;
			 win = (1.35*lost)-lost;
   	         currentbal=currentbal+win;
			 lost=initial;
		}
		else if(counter>2){
			lost=initial;
            //  int cash = currentbal+7000;
			//  win = (1.35*lost)-lost;
			 currentbal+=3500;
			
		}
	     
      }

	}
        printf("\n\n\t\t\t\t\t\tbalance: %d\n",currentbal);
		printf("you're placing %d next.\n",lost);

}

//void finish_with_error(MYSQL*conn){
//fprintf(stderr,"%s\n",mysql_error(conn));
//mysql_close(conn);
//exit(1);
//}
