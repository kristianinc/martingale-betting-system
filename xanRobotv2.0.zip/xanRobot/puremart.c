#include<stdio.h>
#include<stdlib.h>
//#include<winsock2.h>
//#include<mysql.h>
//#include<time.h>

	int i,n,j,m,count;
	int counter=0;
	int sum	= 0;
	int sumlost=10000;
	int placed[100000];
    int initial=10000; // initial stake

int main(){

//MYSQL *conn;
//conn = mysql_init(0);
//conn = mysql_real_connect(conn,"localhost","root","","xanrobot",0,NULL,0);
//if(conn){
//    printf("xanrobot launched successfully\n\n");
//}
//else {printf("you are offline!\n\n");
// exit(0);
//  }

int A[400]={1,1,0,1,1,1,1,1,0,0,1,1,0,1,1,0,0,0,1,0,
           1,1,0,1,1,1,1,1,0,0,1,1,0,1,1,1,0,1,1,0,
		   1,1,0,1,1,1,1,1,0,0,1,1,0,1,1,1,0,1,1,0,
		   1,1,0,1,1,1,1,1,0,0,1,1,0,1,1,1,0,1,1,0,
		   1,1,0,1,1,1,1,0,0,0,1,1,0,0,1,1,0,1,1,0,
		   1,1,0,1,1,1,1,1,0,0,1,1,0,1,1,1,0,1,1,0,
		   1,1,0,1,1,1,1,1,0,0,1,1,0,1,1,1,0,1,1,0,
		   1,1,0,1,1,1,1,1,0,0,1,1,0,1,1,1,0,1,1,0,
		   1,1,0,1,1,1,1,1,0,0,0,1,1,0,0,1,0,1,1,0,
		   1,1,0,1,1,1,1,1,0,0,1,1,0,1,1,1,0,1,1,0,
		   1,1,0,1,1,1,1,1,0,0,1,1,0,1,1,1,0,1,1,0,
		   1,1,0,1,1,1,1,1,0,0,1,1,0,1,1,1,0,1,1,0,
		   1,1,0,1,1,1,1,0,0,0,1,1,0,1,1,1,0,1,1,0,
		   1,1,0,1,1,1,1,1,0,1,0,1,0,1,1,1,0,1,1,0,
		   1,1,0,1,0,1,0,1,0,0,1,1,0,1,1,1,0,1,1,0,
		   1,1,0,1,1,1,1,1,0,0,1,1,0,1,1,1,0,1,1,0,
		   1,1,0,1,0,0,0,1,0,0,1,1,0,1,1,1,0,1,1,0,
		   1,1,0,1,1,1,1,1,0,0,1,1,0,1,1,1,0,1,1,0,
		   1,1,0,1,1,1,1,1,0,0,1,1,0,1,1,1,0,1,1,0,
		   1,1,0,1,1,1,1,1,0,0,1,1,0,1,1,1,0,0,1,0};  // data for 5 months
		   
int B[20]= {1,1,0,1,1,1,1,1,0,0,1,1,0,1,1,1,0,1,1,0};

int trades[56]={1,1,1,1,1,1,0,0,0,1,1,0,0,1,1,0,1,0,1,1,
                1,1,1,1,1,1,0,1,1,1,0,0,1,1,1,1,1,0,1,1,
				0,1,1,1,1,0,1,0,1,1,1,1,0,1,1,0};

int C[5]= {1,1,0,1,1};
           

	printf("=======| XANROBOT |=======\n\n");

  int total= bankroll();
  //printf("\ntotal cash needed for 4 times is %d\n",total);

	//Decision(trades,56);
    Decision(A,400);

}


int bankroll(){

       for(i=0;i<4;i++){
	printf("%d: %d\n",(i+1),sumlost);

		placed[i]=sumlost;

		//for loop for calculating the sum.
		for(j=i;j<=i;j++){
			sum+=placed[j];
		}

		sumlost=(sum+3100)/0.35;

	}
            //printf("\t\t\t%d\n",sum);
			return sum;
}



void Decision(int arr[], int n){
 int currentbal=750000;
 int lost=initial;
 int sum1=0, loss=0;
 int placed1[100000];

	printf("");


		   for(i=0;i<n;i++){

		   	if(arr[i]==0){

				   
					   placed1[i]=lost;
					   for(j=i;j<=i;j++){   //for loop for calculating the sum.
			            sum1+=placed1[j];
					   }
		
		
			
     

         lost=(sum1+3100)/0.35;
    	 loss=placed1[i];
		   
		 
    	 currentbal= currentbal-loss;
		 if (currentbal<350000)
		 {
			printf("\n you failed\n");
			 exit(0);
		 }
		 

				   }
    	    

   else if(arr[i]==1){
 int win;

        win = (1.35*lost)-lost;
        currentbal=currentbal+win;
        lost=initial;
        sum1=0;
		if (currentbal<350000)
		 {
			printf("\n you failed\n");
			 exit(0);
		 }
	     
      }

	}
        printf("\n\n\t\t\t\t\t\tbalance: %d \t\t\t\tprofit: %d\n",currentbal,(currentbal-750000));
		printf("\n\t\t\t\t\t\tyou're placing %d next.\n",lost);

}

